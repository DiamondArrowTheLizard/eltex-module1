#!/bin/bash

SCRIPT_NAME=$(basename "$0")
PID=$$
CUCKOO_PIPE="/tmp/run/cuckoo.pid"
CUCKOO_LOG="cuckoo.log"
MY_LOG="report_${SCRIPT_NAME}.log"


get_now() {
    date '+%d.%m.%Y %H:%M:%S'
}


if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

echo "$(get_now) [$PID] Скрипт запущен" >> "$MY_LOG"

if [[ -p "$CUCKOO_PIPE" ]]; then
    echo "${SCRIPT_NAME}[${PID}]: how much time do I have?" > "$CUCKOO_PIPE"
    sleep 1
    
    N=$(grep "${SCRIPT_NAME}\[${PID}\]" "$CUCKOO_LOG" | tail -n 1 | awk '{print $NF}')
    
    if [[ -z "$N" ]]; then
        echo "Ошибка: не удалось получить время от cuckoo."
        exit 1
    fi
    
    sleep "$N"

    echo "$(get_now) [$PID] Скрипт завершился, работал $N секунд." >> "$MY_LOG"
else
    echo "Ошибка: канал $CUCKOO_PIPE не найден"
    exit 1
fi

