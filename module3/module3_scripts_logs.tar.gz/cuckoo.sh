#!/bin/bash


PIPE="/tmp/run/cuckoo.pid"
LOGFILE="cuckoo.log"


mkdir -p /tmp/run/
[[ -p $PIPE ]] || mkfifo $PIPE


log_message() {
	echo "$(date '+%d.%m.%Y %H:%M:%S') $1" >> "$LOGFILE"
}


cleanup() {
	log_message "Shutdown!"
	rm -f "$PIPE"
	exit 0
}


trap cleanup SIGINT SIGTERM

log_message "Startup!"

while true; do
	if read line < "$PIPE"; then
		# Regex: NAME[PID]: how much time do I have?
		if [[ $line =~ ^(.*)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\? ]]; then
			NAME="${BASH_REMATCH[1]}"
			PID="${BASH_REMATCH[2]}"
			N=$(( RANDOM % 9 + 2 ))
			log_message "$NAME[$PID] $N"
		fi
	fi
done

