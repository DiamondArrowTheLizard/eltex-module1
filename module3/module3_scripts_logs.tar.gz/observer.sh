#!/bin/bash

CONF_FILE="observer.conf"
LOG_FILE="observer.log"

if [[ ! -f "$CONF_FILE" ]]; then
    echo "$(date '+%d.%m.%Y %H:%M:%S') [ERROR] Конфигурационный файл $CONF_FILE не найден!" >> "$LOG_FILE"
    exit 1
fi

while read -r SCRIPT_NAME || [[ -n "$SCRIPT_NAME" ]]; do
    
    [[ -z "$SCRIPT_NAME" || "$SCRIPT_NAME" =~ ^# ]] && continue
    FOUND=false
    
    for cmdline in /proc/[0-9]*/cmdline; do
        
        if grep -q -a "$SCRIPT_NAME" "$cmdline" 2>/dev/null; then
            FOUND=true
            break
        fi
    done

    if [ "$FOUND" = false ]; then
        echo "$(date '+%d.%m.%Y %H:%M:%S') $SCRIPT_NAME перезапущен" >> "$LOG_FILE"
        nohup ./"$SCRIPT_NAME" > /dev/null 2>&1 &
    fi

done < "$CONF_FILE"

